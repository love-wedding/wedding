# HƯỚNG DẪN CHIẾU SLIDE CƯỚI MÀN HÌNH LED 16:9

Dự án slide cưới cao cấp được thiết kế và lập trình bằng **HTML5 / CSS3 / JavaScript**, tái tạo chuẩn 100% phong cách từ video mẫu `Download.mp4` chiếu trên màn hình LED tiệc cưới.

---

## 1. Cách Mở Và Trình Chiếu

Bạn có thể mở slide theo 2 cách cực kỳ đơn giản:

### Cách 1: Mở trực tiếp (Không cần cài đặt, không cần mạng)
- Vào thư mục `slide-cuoi-1`, nhấp đúp trực tiếp vào file **`index.html`** để mở bằng bất kỳ trình duyệt nào (Chrome, Edge, Cốc Cốc, Safari, Firefox,...).
- Trên màn hình hiển thị, bấm nút **"BẮT ĐẦU TRÌNH CHIẾU & PHÁT NHẠC"** (hoặc bấm phím `Space`/phím `F`).

### Cách 2: Mở qua máy chủ nội bộ (Local Server)
- File `server.js` đang chạy ngầm sẵn trên máy ở địa chỉ:
  👉 **`http://localhost:8899/`**
- Hoặc mở terminal và gõ: `node server.js` rồi truy cập vào link trên.

---

## 2. Các Phím Tắt Tiện Lợi Khi Chiếu Trên Sân Khấu (MC / Kỹ Thuật Viên)

| Phím Tắt | Chức Năng |
| :--- | :--- |
| **`F`** hoặc **`F11`** | **Bật / Tắt Toàn Màn Hình (Fullscreen)** chuẩn tỉ lệ 16:9 tràn viền LED |
| **`Space`** (Phím cách) | **Dừng (Pause) / Tiếp tục (Play)** slide và nhạc nền |
| **`→`** (Mũi tên phải) | Chuyển ngay sang **Slide kế tiếp** |
| **`←`** (Mũi tên trái) | Quay lại **Slide trước đó** |
| **`M`** | **Bật / Tắt âm thanh (Mute/Unmute)** nhạc nền |
| **`S`** | **Mở bảng Cài Đặt (Settings)** để đổi tên Cô Dâu - Chú Rể, Ngày cưới trực tiếp |
| **`R`** | Quay về **Slide mở đầu (Intro)** |
| **`Esc`** | Đóng bảng cài đặt / Thoát toàn màn hình |

> **Tính năng tự ẩn con trỏ chuột & thanh điều khiển**: Sau 3 giây không chạm chuột, thanh điều khiển và con trỏ chuột sẽ tự động biến mất hoàn toàn để màn hình LED luôn sạch đẹp và sang trọng như một video 4K phát sóng trực tiếp.

---

## 3. Các Điểm Nổi Bật Tái Tạo Từ Video Mẫu

1. **Khung hình chuẩn 16:9 widescreen**: Khóa cứng tỉ lệ chuẩn màn hình LED sân khấu tiệc cưới, tự động căn giữa và không bao giờ bị méo hình.
2. **Hiệu ứng Cột Sáng Lung Linh (Light Beam & Bokeh)**: Cột ánh sáng vàng champagne lung linh ở slide mở đầu kết hợp các đốm sáng lấp lánh (sparkle bokeh dust) tạo chiều sâu 3D trên màn hình LED lớn.
3. **Typography & Font chữ chuẩn đám cưới**:
   - Khẩu hiệu: `WE'RE GETTING MARRIED` (chữ in hoa giãn nét tinh tế)
   - Tiêu đề nghệ thuật: `Save the Date` (font thư pháp uốn lượn phong cách sang trọng)
   - Tên cô dâu chú rể: `ANH TÚ & DIỆU NHI` (font serif cổ điển hoàng gia)
   - Ngày cưới: `06.06.2026`
   - Chữ tạp chí thời trang: `NATURAL BREATHING / FIND THE COURAGE TO BE YOURSELF`, `LOVE LIFE forever`,...
4. **Hiệu ứng chuyển cảnh Ken Burns 60fps**: Zoom chậm, pan mượt mà lướt qua chi tiết ảnh và hiệu ứng hòa tan (cross-dissolve) giữa các ảnh cực kỳ nghệ thuật.
5. **Hiển thị ảnh thông minh**:
   - Đối với ảnh dọc: Sử dụng lớp nền mờ Gaussian Ambient 16:9 phía sau + ảnh chính sắc nét nổi bật ở giữa với đổ bóng nhẹ.
   - Đối với ảnh ngang (như ảnh chiếc khăn voan bay): Tràn viền và lia máy từ trái sang phải.
   - Bố cục đôi (Duo Slide): Ghép 2 ảnh dọc song song kèm cột chữ tạp chí ở giữa.
6. **Nhạc nền cưới trọn vẹn**: Tích hợp sẵn bài hát acoustic lãng mạn trích xuất trực tiếp từ video gốc (`music.mp3`), có thanh điều chỉnh âm lượng mượt mà.

---

## 4. Cách Thay Ảnh & Thay Nhạc Sau Này

- **Thay đổi tên & ngày cưới nhanh**: Bấm phím **`S`** ngay trên slide để mở hộp thoại nhập tên cô dâu, chú rể và ngày cưới mới rồi nhấn "Lưu", slide sẽ cập nhật ngay lập tức mà không cần sửa code.
- **Thay ảnh**: Chỉ cần sao chép các ảnh cưới mới vào thư mục `images/` và cập nhật đường dẫn tương ứng trong file `js/app.js` (danh sách `slidesData`).
- **Thay nhạc nền**: Thay file `music.mp3` bằng bài hát yêu thích của bạn (đặt cùng tên `music.mp3`).
